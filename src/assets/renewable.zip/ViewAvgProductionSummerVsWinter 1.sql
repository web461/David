--View for Avg production in Summer vs winter (2022) (July vs January)
USE [SolarProduction]
GO

CREATE VIEW [dbo].[summer_vs_winter] AS

SELECT [name],SUM([kWh]) AS kSUM, [Month]

FROM (SELECT [name],
	[kWh], 
	Datepart(Month, [date]) AS [Month]

	FROM [dbo].[SolarProduction]
 

	WHERE ([date] BETWEEN '2022-07-01' AND '2022-08-1' 
	AND [name] = 'City of Calgary North Corporate Warehouse') 
	OR ([date] BETWEEN '2022-01-01' AND '2022-02-01'
	AND [name] = 'City of Calgary North Corporate Warehouse')

	GROUP BY Datepart(Month, [date]),[name], [kWh]) AS SVW

GROUP BY [name], [Month]


GO


