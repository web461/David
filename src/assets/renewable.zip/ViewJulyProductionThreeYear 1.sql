--View of Monthly Production in July for 1 location over 3 years (2023-2021)
USE [SolarProduction]
GO
CREATE VIEW [dbo].[july_production_3years] AS

SELECT
	  [Name] = [name]
      
      ,[Year] = YEAR([date])
	  
	  ,[Monthly Production kWh] = SUM([kWh])
      
  FROM [dbo].[SolarProduction]
  
  WHERE YEAR([date]) BETWEEN 2021 AND 2023 
	AND MONTH([date]) = 7 
	AND [name] = 'City of Calgary North Corporate Warehouse'
    
  GROUP BY [Name],YEAR([date])

  GO