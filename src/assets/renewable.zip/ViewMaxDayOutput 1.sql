USE SolarProduction
GO
--View for daily output (July 2023) for 1 location
CREATE   VIEW [dbo].[max_daily_output] AS
SELECT
	   [name]
      ,[id]
	  ,[Output Date] = DATEFROMPARTS(DATEPART(YEAR,[date]),DATEPART(MONTH,[date]),DATEPART(DAY,[date]))
      ,[Daily Output kWh] = SUM([kWh])
      
  FROM [SolarProduction].[dbo].[SolarProduction]

  WHERE YEAR([date]) = 2023 AND MONTH([date]) = 7 
		AND [name]='City of Calgary North Corporate Warehouse'
  
  GROUP BY [name],[id],DATEFROMPARTS(DATEPART(YEAR,[date]),DATEPART(MONTH,[date]),DATEPART(DAY,[date]))
  ORDER BY [Daily Output kWh] DESC offset 0 rows;

  GO
 

  
  