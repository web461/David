--View for Compare production between each location avg in month (July 2023)
USE SolarProduction
GO
CREATE   VIEW [dbo].[avg_production_locations] AS

SELECT
	   [name]
      ,[id]
      ,[Average Production kWh] = AVG([kWh])
      
  FROM [SolarProduction].[dbo].[SolarProduction]
  
  WHERE YEAR([date]) = 2023 AND MONTH([date]) = 7    
	
  GROUP BY [name],[id]
     
  ORDER BY [Average Production kWh] DESC offset 0 rows;

GO

