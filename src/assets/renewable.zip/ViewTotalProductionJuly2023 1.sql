--View for Total production from 1 location during 1 month (July 2023)
USE SolarProduction
GO

CREATE   VIEW [dbo].[monthly_total_production] AS
SELECT
	  [name]
      ,[id]
      ,[Total Production kWh] = SUM([kWh])
 

  FROM [dbo].[SolarProduction]
   

  WHERE YEAR([date]) = 2023 AND MONTH([date]) = 7 
  AND [name] = 'City of Calgary North Corporate Warehouse'
   

  GROUP BY [name],[id]

  GO